local ni = ...

ni.debug = {
	print = function(string)
		if ni.vars.debug then
			print("\124cffff0000" .. string);
		end
	end,
	log = function(string)
	
	end
}
